from flask import Flask, request, jsonify, render_template_string
import socket
import threading

app = Flask(__name__)

HTML_PAGE = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Network Port Scanner</title>
<style>
  body { font-family: Arial, sans-serif; margin: 20px; }
  input, button { padding: 8px; margin: 5px; }
  #results { margin-top: 20px; }
  .open { color: green; }
  .closed { color: red; }
</style>
</head>
<body>
  <h1>Network Port Scanner</h1>
  <label>Host/IP: <input type="text" id="host" placeholder="e.g. 192.168.1.1" /></label><br />
  <label>Start Port: <input type="number" id="startPort" value="1" min="1" max="65535" /></label><br />
  <label>End Port: <input type="number" id="endPort" value="1024" min="1" max="65535" /></label><br />
  <button onclick="startScan()">Start Scan</button>

  <div id="results"></div>

  <script>
    async function startScan() {
      const host = document.getElementById('host').value;
      const startPort = document.getElementById('startPort').value;
      const endPort = document.getElementById('endPort').value;
      const resultsDiv = document.getElementById('results');
      resultsDiv.innerHTML = 'Scanning...';

      const response = await fetch('/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ host, start_port: startPort, end_port: endPort })
      });

      if (!response.ok) {
        resultsDiv.innerHTML = 'Error scanning ports.';
        return;
      }

      const results = await response.json();
      let output = '<h2>Scan Results</h2><ul>';
      for (const port in results) {
        const status = results[port];
        output += `<li>Port ${port}: <span class="${status.toLowerCase()}">${status}</span></li>`;
      }
      output += '</ul>';
      resultsDiv.innerHTML = output;
    }
  </script>
</body>
</html>
"""

def scan_port(host, port, results):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)
    try:
        sock.connect((host, port))
        results[port] = 'Open'
    except:
        results[port] = 'Closed'
    finally:
        sock.close()

@app.route('/')
def index():
    return render_template_string(HTML_PAGE)

@app.route('/scan', methods=['POST'])
def scan():
    data = request.json
    host = data.get('host')
    start_port = int(data.get('start_port', 1))
    end_port = int(data.get('end_port', 1024))

    results = {}
    threads = []

    for port in range(start_port, end_port + 1):
        t = threading.Thread(target=scan_port, args=(host, port, results))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
